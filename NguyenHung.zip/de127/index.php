<?php
require_once 'app/conn.php';
require_once 'app/handle.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản lý nhân viên</title>
    <link rel="stylesheet" href="asset/style.css">
</head>

<body>
    <div class="container">
        <!-- header -->
        <div class="header">
            <h1>Quản lý nhân viên</h1>
        </div>
        <!-- header end -->

        <div class="content">
            <div class="header-bd">
                <!-- Danh sách nhân viên -->
                <h2 style="text-align: center">Danh sách nhân viên</h2>

                <?php if (!empty($employees)) { ?>
                    <table>
                        <tr>
                            <th>ID</th>
                            <th>Tên nhân viên</th>
                            <th>Địa chỉ</th>
                            <th>Lương</th>
                            <th></th>
                            <th></th>
                        </tr>

                        <?php foreach ($employees as $employee) : ?>
                            <tr>
                                <td><?php echo $employee['id']; ?></td>
                                <td><?php echo $employee['fullname']; ?></td>
                                <td><?php echo $employee['address']; ?></td>
                                <td><?php echo number_format($employee['salary']); ?></td>
                                <td><a href="app/update_employee.php?id=<?php echo $employee['id']; ?>">Sửa</a></td>
                                <td><a href="index.php?delete_employee=<?php echo $employee['id']; ?>">Xóa</a></td>
                            </tr>
                        <?php endforeach; ?>
                    </table>

                <?php } else { ?>
                    <p>Không tìm thấy nhân viên nào!</p>
                <?php } ?>
            </div>
            <div class="left-body">
                <!-- Thêm nhân viên mới -->
                <h2>Thêm nhân viên mới</h2>

                <form method="POST" class="left-flex" action="index.php">
                    <div class="form-group">
                        <label for="fullname">Tên nhân viên:</label>
                        <input type="text" name="fullname" id="fullname" placeholder="Nguyen Van A" required>
                    </div>

                    <div class="form-group">
                        <label for="address">Địa chỉ:</label>
                        <input type="text" name="address" id="address" placeholder="Ha Noi">
                    </div>

                    <div class="form-group">
                        <label for="salary">Lương:</label>
                        <input type="number" name="salary" id="salary" min="0" placeholder="1000" required>
                    </div>

                    <div class="form-group">
                        <input type="submit" name="add_employee" value="Thêm nhân viên">
                    </div>
                </form>
            </div>
            <!-- Tìm kiếm nhân viên -->
            <div class="right-body">
                <h2>Tìm kiếm nhân viên</h2>

                <form method="GET" class="right-flex" action="index.php">
                    <div class="form-group">
                        <label for="search_name">Tìm kiếm theo tên:</label>
                        <input type="text" name="search_name" id="search_name" placeholder="Hung">
                        <input type="submit" value="Tìm kiếm">
                    </div>
                </form>

                <form method="GET" class="right-flex" action="index.php">
                    <div class="form-group">
                        <label for="salary_min">Tìm kiếm theo khoảng lương:</label>
                        <input type="number" name="salary_min" id="salary_min" min="0" step="1" placeholder="Min Salary" required>
                        -
                        <input type="number" name="salary_max" id="salary_max" min="0" step="1" placeholder="Max Salary" required>
                        <input type="submit" value="Tìm kiếm">
                    </div>
                </form>
            </div>
            <div class="footer-bd">
                <?php if (isset($_GET['delete_employee'])) { ?>
                    <div class="alert alert-success">Xóa nhân viên thành công!</div>
                <?php } ?>

                <?php if (isset($_POST['add_employee'])) { ?>
                    <div class="alert alert-success">Thêm nhân viên mới thành công!</div>
                <?php } ?>

                <?php if (isset($_POST['update_employee'])) { ?>
                    <div class="alert alert-success">Cập nhật thông tin nhân viên thành công!</div>
                <?php } ?>

                <?php if (isset($_GET['search_name']) || isset($_GET['salary_min'])) { ?>
                    <?php if (empty($employees)) { ?>
                        <div class="alert alert-danger">Không tìm thấy kết quả phù hợp!</div>
                    <?php } else { ?>
                        <div class="alert alert-success">Tìm thấy <?php echo count($employees); ?> kết quả:</div>
                    <?php } ?>
                <?php } ?>
            </div>
        </div>

        <!-- Footer -->
        <div class="footer">
            <p>Bản quyền &copy; 2023. Được phát triển bởi Nguyễn Doanh Hưng.</p>
        </div>
        <!-- Footer end -->
    </div>
</body>

</html>