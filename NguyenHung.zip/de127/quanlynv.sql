CREATE DATABASE quanlynv;
USE quanlynv;

CREATE TABLE Employee (
id INT PRIMARY KEY AUTO_INCREMENT,
fullname VARCHAR(50) NOT NULL,
address VARCHAR(100),
salary FLOAT CHECK(salary > 0),
status BIT DEFAULT 1
);

INSERT INTO Employee(fullname, address, salary) VALUES 
('Nguyen Van A', 'Ha Noi', 1000),
('Tran Thi B', 'Hai Phong', 1500),
('Le Van C', 'Da Nang', 2000),
('Pham Thi D', 'Ho Chi Minh', 2500);
