<?php
// Lấy danh sách nhân viên từ cơ sở dữ liệu
$query = "SELECT * FROM Employee";
$result = mysqli_query($conn, $query);

if (!$result) {
    die('Failed to fetch data from database!');
}

$employees = [];
while ($row = mysqli_fetch_assoc($result)) {
    $employees[] = $row;
}

// Xử lý lệnh thêm nhân viên mới
if (isset($_POST['add_employee'])) {
    $fullname = $_POST['fullname'];
    $address = $_POST['address'];
    $salary = $_POST['salary'];

    $query = "INSERT INTO Employee (fullname, address, salary) VALUES ('$fullname', '$address', '$salary')";
    $result = mysqli_query($conn, $query);

    if (!$result) {
        die('Failed to add new employee!');
    }
}

// // Xử lý lệnh cập nhật thông tin nhân viên
// if (isset($_POST['update_employee'])) {
//     $id = $_POST['id'];
//     $fullname = $_POST['fullname'];
//     $address = $_POST['address'];
//     $salary = $_POST['salary'];

//     $query = "UPDATE Employee SET fullname = '$fullname', address = '$address', salary = '$salary' WHERE id = '$id'";
//     $result = mysqli_query($conn, $query);

//     if (!$result) {
//         die('Failed to update employee information!');
//     }
// }

// Xử lý lệnh xóa nhân viên
if (isset($_GET['delete_employee'])) {
    $id = $_GET['delete_employee'];

    $query = "DELETE FROM Employee WHERE id = '$id'";
    $result = mysqli_query($conn, $query);

    if (!$result) {
        die('Failed to delete employee!');
    }
}

// Xử lý lệnh tìm kiếm nhân viên theo tên
if (isset($_GET['search_name'])) {
    $name = $_GET['search_name'];

    $query = "SELECT * FROM Employee WHERE fullname LIKE '%$name%'";
    $result = mysqli_query($conn, $query);

    if (!$result) {
        die('Failed to fetch data from database!');
    }

    $employees = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $employees[] = $row;
    }
}

// Xử lý lệnh tìm kiếm nhân viên theo khoảng lương
if (isset($_GET['salary_min']) && isset($_GET['salary_max'])) {
    $salary_min = $_GET['salary_min'];
    $salary_max = $_GET['salary_max'];

    $query = "SELECT * FROM Employee WHERE salary BETWEEN '$salary_min' AND '$salary_max'";
    $result = mysqli_query($conn, $query);

    if (!$result) {
        die('Failed to fetch data from database!');
    }

    $employees = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $employees[] = $row;
    }
}

?>