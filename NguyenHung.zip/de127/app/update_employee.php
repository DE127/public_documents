<?php
// require_once 'conn.php';

// Kết nối đến cơ sở dữ liệu
$conn = mysqli_connect('localhost', 'root', '', 'quanlynv');

// Kiểm tra kết nối
if (!$conn) {
    die('Failed to connect to database!');
}

// Lấy thông tin nhân viên cần sửa
$id = $_GET['id'];

$query = "SELECT * FROM Employee WHERE id = '$id'";
$result = mysqli_query($conn, $query);

if (!$result) {
    die('Failed to fetch data from database!');
}

$employee = mysqli_fetch_assoc($result);

// Xử lý lệnh cập nhật thông tin nhân viên
if (isset($_POST['update_employee'])) {
    $id = $_POST['id'];
    $fullname = $_POST['fullname'];
    $address = $_POST['address'];
    $salary = $_POST['salary'];

    $query = "UPDATE Employee SET fullname = '$fullname', address = '$address', salary = '$salary' WHERE id = '$id'";
    $result = mysqli_query($conn, $query);

    if (!$result) {
        die('Failed to update employee information!');
    }

    header('Location: index.php');
    exit();
}

?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sửa thông tin nhân viên</title>
    <!-- CSS styles -->
    <style>
        h1 {
            font-family: Arial, sans-serif;
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 10px;
        }

        label {
            display: block;
            margin-bottom: 5px;
        }

        input[type="text"],
        input[type="number"] {
            padding: 5px 10px;
            border-radius: 4px;
            border: 1px solid #ccc;
            margin-bottom: 10px;
        }

        input[type="submit"],
        button {
            padding: 5px 10px;
            background-color: #2ecc71;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .container {
            background-color: aqua;
            border-radius: 15px;
            box-shadow: 13px 14px 38px -21px rgba(0, 0, 0, 0.82);
            -webkit-box-shadow: 13px 14px 38px -21px rgba(0, 0, 0, 0.82);
            -moz-box-shadow: 13px 14px 38px -21px rgba(0, 0, 0, 0.82);
            margin: 40px auto;
            width: 300px;
            padding: 20px;
        }
    </style>
</head>

<body>
    <div class="container">
        <h1>Sửa thông tin nhân viên</h1>
        <form method="POST" action="app/update_employee.php">
            <input type="hidden" name="id" value="<?php echo $employee['id']; ?>">

            <div class="form-group">
                <label for="fullname">Tên nhân viên:</label>
                <input type="text" name="fullname" id="fullname" value="<?php echo $employee['fullname']; ?>" required>
            </div>

            <div class="form-group">
                <label for="address">Địa chỉ:</label>
                <input type="text" name="address" id="address" value="<?php echo $employee['address']; ?>">
            </div>

            <div class="form-group">
                <label for="salary">Lương:</label>
                <input type="number" name="salary" id="salary" value="<?php echo $employee['salary']; ?>" min="0" required>
            </div>

            <div class="form-group">
                <input type="submit" name="update_employee" value="Lưu thay đổi">
            </div>

        </form>
        <div class="">
            <button onclick="window.location.href='/de127/index.php'">Cancel</button>
        </div>
    </div>
</body>

</html>