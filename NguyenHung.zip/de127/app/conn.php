<?php
//    $host = "localhost";
//    $username  = "root";
//    $passwd = "password";
//    $dbname = "mydb";

// Kết nối đến cơ sở dữ liệu
$conn = mysqli_connect('localhost', 'root', '', 'quanlynv');

// Kiểm tra kết nối
if (!$conn) {
    die('Failed to connect to database!');
}
